# Venue, funding and collaboration radar — smoke oriented bounding boxes for aerial objec

**Topic:** oriented bounding boxes for aerial object detection

## Venues

| Venue (as seen in literature) | Verification | Publisher | ISSN | Papers | Note |
|---|---|---|---|---|---|
| arXiv cs.CV | unverified | — | — | 4 | Crossref returned no matching journal record; treat this venue as unverified. |
| arXiv cs.CV/cs.AI | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |
| Data in Brief | verified | Elsevier | 2352-3409 | 1 | Verified: near-exact title match in the Crossref journal registry (title/ISSN/publisher). Impact fac |
| Communications in Computer and Information Science | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |
| 2026 International Conference on Information Technology and Computing (ICITCOM) | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |

## Funders active in this literature

_No funder metadata was available on the retrieved records._

## Collaboration candidates

| Name | Papers in corpus | Latest year | Institutions | Evidence |
|---|---|---|---|---|

> Research similarity is not evidence of availability, willingness or funding. Contact details are never inferred.