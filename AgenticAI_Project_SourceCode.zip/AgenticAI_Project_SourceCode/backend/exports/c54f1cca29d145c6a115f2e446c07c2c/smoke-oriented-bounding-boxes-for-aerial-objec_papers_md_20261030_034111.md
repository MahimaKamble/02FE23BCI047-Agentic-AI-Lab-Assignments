# Literature list — smoke oriented bounding boxes for aerial objec

**Topic:** oriented bounding boxes for aerial object detection  
**Records:** 10  
**Exported:** 2026-10-30T03:41:11+00:00  
**Provenance:** retrieved from OpenAlex / Crossref / arXiv by project `c54f1cca29d145c6a115f2e446c07c2c`

| # | Title | Year | Venue | Identifier | Sources | Rank |
|---|---|---|---|---|---|---|
| 1 | Improving the Detection of Small Oriented Objects in Aerial Images | 2024 | arXiv cs.CV/cs.AI | 10.1109/wacvw58289.2023.00023 | arxiv | 0.611 |
| 2 | Oriented object detection in optical remote sensing images using deep learning: a survey | 2023 | arXiv cs.CV | 10.1007/s10462-025-11256-0 | arxiv | 0.591 |
| 3 | Oriented Object Detection in Aerial Images with Box Boundary-Aware Vectors | 2020 | arXiv cs.CV | arXiv:2008.07043 | arxiv | 0.580 |
| 4 | Enhancing Rotated Object Detection via Anisotropic Gaussian Bounding Box and Bhattacharyya Distance | 2025 | arXiv cs.CV | 10.1016/j.neucom.2025.129432 | arxiv | 0.554 |
| 5 | Gliding vertex on the horizontal bounding box for multi-oriented object detection | 2019 | arXiv cs.CV | 10.1109/tpami.2020.2974745 | arxiv | 0.490 |
| 6 | UAV-OBB: An aerial urban vehicle dataset with oriented bounding boxes for remote sensing object detection in s | 2026 | Data in Brief | 10.1016/j.dib.2026.112710 | crossref | 0.481 |
| 7 | Horizontal vs Oriented Bounding Boxes in Aerial Object Detection Integrating Symbolic Reasoning with Oriented  | 2026 | Communications in Computer and Informati | 10.1007/978-3-032-36547-7_43 | crossref | 0.475 |
| 8 | Oriented Object Detection for Badminton Rackets Using Rotated Bounding Boxes | 2026 | 2026 International Conference on Informa | 10.1109/icitcom70739.2026.11714364 | crossref | 0.427 |
| 9 | Rotated R-CNN: A Two-Stage Object Detection Method Adapted To Oriented Bounding Boxes | 2024 | 2024 IEEE International Conference on Im | 10.1109/icip51287.2024.10647377 | crossref | 0.400 |
| 10 | Segmentation based rotated bounding boxes prediction and image synthesizing for object detection of high resol | 2020 | Neurocomputing | 10.1016/j.neucom.2020.01.039 | crossref | 0.371 |