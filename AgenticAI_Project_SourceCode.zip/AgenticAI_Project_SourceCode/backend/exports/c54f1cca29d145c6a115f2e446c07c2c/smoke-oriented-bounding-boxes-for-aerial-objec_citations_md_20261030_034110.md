# Citation audit — smoke oriented bounding boxes for aerial objec

**Topic:** oriented bounding boxes for aerial object detection
**Draft version:** 1

| Check | Result |
|---|---|
| References | 10 |
| In-text markers | 10 |
| DOI resolved | 9 |
| DOI failed | 0 |
| DOI unavailable | 1 |
| Missing bibliography entries | 0 |
| Unused bibliography entries | 0 |
| Duplicate references | 0 |

> Metadata verification confirms that a DOI resolves and that title/year/authors broadly agree. It does NOT show that the source supports any specific claim in the manuscript. Claim-level checking requires reading the cited text and is out of scope for this automated audit.

## Per-reference results

| Key | Title | DOI | Metadata check | Issues |
|---|---|---|---|---|
| P1 | Improving the Detection of Small Oriented Objects in Aerial  | 10.1109/wacvw58289.2023.00023 | verified | none |
| P2 | Oriented object detection in optical remote sensing images u | 10.1007/s10462-025-11256-0 | verified | year mismatch: draft says 2023, registry says 2025 |
| P3 | Oriented Object Detection in Aerial Images with Box Boundary | — | unavailable | no DOI for this record — metadata cannot be verified automatically |
| P4 | Enhancing Rotated Object Detection via Anisotropic Gaussian  | 10.1016/j.neucom.2025.129432 | verified | none |
| P5 | Gliding vertex on the horizontal bounding box for multi-orie | 10.1109/tpami.2020.2974745 | verified | year mismatch: draft says 2019, registry says 2021 |
| P6 | UAV-OBB: An aerial urban vehicle dataset with oriented bound | 10.1016/j.dib.2026.112710 | verified | none |
| P7 | Horizontal vs Oriented Bounding Boxes in Aerial Object Detec | 10.1007/978-3-032-36547-7_43 | verified | none |
| P8 | Oriented Object Detection for Badminton Rackets Using Rotate | 10.1109/icitcom70739.2026.11714364 | verified | none |
| P9 | Rotated R-CNN: A Two-Stage Object Detection Method Adapted T | 10.1109/icip51287.2024.10647377 | verified | none |
| P10 | Segmentation based rotated bounding boxes prediction and ima | 10.1016/j.neucom.2020.01.039 | verified | none |