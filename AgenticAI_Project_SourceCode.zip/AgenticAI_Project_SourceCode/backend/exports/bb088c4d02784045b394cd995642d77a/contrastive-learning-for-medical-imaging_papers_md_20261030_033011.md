# Literature list — Contrastive Learning for Medical Imaging

**Topic:** contrastive learning for medical image segmentation  
**Records:** 14  
**Exported:** 2026-10-30T03:30:11+00:00  
**Provenance:** retrieved from OpenAlex / Crossref / arXiv by project `bb088c4d02784045b394cd995642d77a`

| # | Title | Year | Venue | Identifier | Sources | Rank |
|---|---|---|---|---|---|---|
| 1 | Pixel-level Counterfactual Contrastive Learning for Medical Image Segmentation | 2026 | arXiv (Cornell University) | https://openalex.org/W7139147888 | openalex | 0.731 |
| 2 | Class-aware Patch Based Contrastive Learning for Medical Image Segmentation | 2024 | International Joint Conference on Neural | 10.1109/ijcnn60899.2024.10650546 | openalex | 0.722 |
| 3 | A Medical Image Segmentation Method Combining Knowledge Distillation and Contrastive Learning | 2024 | 電腦學刊 | 10.53106/199115992024063503024 | crossref | 0.722 |
| 4 | Stronger is not better: Better Augmentations in Contrastive Learning for Medical Image Segmentation | 2025 | arXiv (Cornell University) | 10.48550/arxiv.2512.05992 | openalex | 0.703 |
| 5 | Learning With Context Feedback Loop for Robust Medical Image Segmentation | 2021 | arXiv eess.IV/cs.CV | 10.1109/tmi.2021.3060497 | arxiv | 0.640 |
| 6 | Weakly-Supervised 3D Medical Image Segmentation using Geometric Prior and Contrastive Similarity | 2023 | arXiv eess.IV/cs.CV | 10.1109/tmi.2023.3269523 | arxiv | 0.599 |
| 7 | Cross-dimensional transfer learning in medical image segmentation with deep learning | 2023 | arXiv eess.IV/cs.CV | 10.1016/j.media.2023.102868 | arxiv | 0.563 |
| 8 | Multi-modal hypergraph contrastive learning for medical image segmentation | 2025 | Pattern Recognition | 10.1016/j.patcog.2025.111544 | openalex | 0.495 |
| 9 | Distributed contrastive learning for medical image segmentation | 2022 | Medical Image Analysis | 10.1016/j.media.2022.102564 | openalex, crossref | 0.493 |
| 10 | Building medical image classifiers with very limited data using segmentation networks | 2018 | arXiv cs.CV | 10.1016/j.media.2018.07.010 | arxiv | 0.483 |
| 11 | SuperCL: Superpixel Guided Contrastive Learning for Medical Image Segmentation Pre-training_supp1-3657233.pdf | 2026 | Institute of Electrical and Electronics  | 10.1109/tip.2026.3657233/mm1 | crossref | 0.457 |
| 12 | Contrastive learning for unsupervised representation and semi-supervised learning for medical image segmentati | 2026 | Less-supervised Segmentation with CNNs | 10.1016/b978-0-32-395674-1.00013-5 | crossref | 0.457 |
| 13 | Fréchet Radiomic Distance (FRD): A Versatile Metric for Comparing Medical Imaging Datasets | 2024 | arXiv cs.CV/cs.LG | 10.1016/j.media.2026.103943 | arxiv | 0.457 |
| 14 | Combining Contrastive Learning and Shape Awareness for Semi-Supervised Medical Image Segmentation | 2023 | Elsevier BV | 10.2139/ssrn.4474900 | crossref | 0.386 |