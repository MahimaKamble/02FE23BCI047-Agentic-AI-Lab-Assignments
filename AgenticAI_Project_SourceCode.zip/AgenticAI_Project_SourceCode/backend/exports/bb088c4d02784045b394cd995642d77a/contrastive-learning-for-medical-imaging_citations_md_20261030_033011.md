# Citation audit — Contrastive Learning for Medical Imaging

**Topic:** contrastive learning for medical image segmentation
**Draft version:** 1

| Check | Result |
|---|---|
| References | 12 |
| In-text markers | 12 |
| DOI resolved | 11 |
| DOI failed | 0 |
| DOI unavailable | 1 |
| Missing bibliography entries | 0 |
| Unused bibliography entries | 0 |
| Duplicate references | 0 |

> Metadata verification confirms that a DOI resolves and that title/year/authors broadly agree. It does NOT show that the source supports any specific claim in the manuscript. Claim-level checking requires reading the cited text and is out of scope for this automated audit.

## Per-reference results

| Key | Title | DOI | Metadata check | Issues |
|---|---|---|---|---|
| P1 | Pixel-level Counterfactual Contrastive Learning for Medical  | — | unavailable | no DOI for this record — metadata cannot be verified automatically |
| P2 | Class-aware Patch Based Contrastive Learning for Medical Ima | 10.1109/ijcnn60899.2024.10650546 | verified | none |
| P3 | A Medical Image Segmentation Method Combining Knowledge Dist | 10.53106/199115992024063503024 | verified | none |
| P4 | Stronger is not better: Better Augmentations in Contrastive  | 10.48550/arxiv.2512.05992 | verified | none |
| P5 | Learning With Context Feedback Loop for Robust Medical Image | 10.1109/tmi.2021.3060497 | verified | none |
| P6 | Weakly-Supervised 3D Medical Image Segmentation using Geomet | 10.1109/tmi.2023.3269523 | verified | none |
| P7 | Cross-dimensional transfer learning in medical image segment | 10.1016/j.media.2023.102868 | verified | none |
| P8 | Multi-modal hypergraph contrastive learning for medical imag | 10.1016/j.patcog.2025.111544 | verified | none |
| P9 | Distributed contrastive learning for medical image segmentat | 10.1016/j.media.2022.102564 | verified | none |
| P10 | Building medical image classifiers with very limited data us | 10.1016/j.media.2018.07.010 | verified | none |
| P11 | SuperCL: Superpixel Guided Contrastive Learning for Medical  | 10.1109/tip.2026.3657233/mm1 | verified | none |
| P12 | Contrastive learning for unsupervised representation and sem | 10.1016/b978-0-32-395674-1.00013-5 | verified | none |