# Venue, funding and collaboration radar — Contrastive Learning for Medical Imaging

**Topic:** contrastive learning for medical image segmentation

## Venues

| Venue (as seen in literature) | Verification | Publisher | ISSN | Papers | Note |
|---|---|---|---|---|---|
| arXiv eess.IV/cs.CV | unverified | — | — | 3 | Crossref returned no matching journal record; treat this venue as unverified. |
| arXiv (Cornell University) | unverified | — | — | 2 | Crossref returned no matching journal record; treat this venue as unverified. |
| International Joint Conference on Neural Networks (IJCNN) | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |
| 電腦學刊 | verified | Computer Society of the Republic of China | 1991-1599 | 1 | Verified against the Crossref journal registry (title/ISSN/publisher). Impact factor and acceptance  |
| Pattern Recognition | verified | Elsevier | 0031-3203 | 1 | Verified against the Crossref journal registry (title/ISSN/publisher). Impact factor and acceptance  |

## Funders active in this literature

- **National Natural Science Foundation of China** — 5 paper(s) in corpus; awards: 82371112, 62501020, 62176231
- **National Science Foundation** — 3 paper(s) in corpus; awards: 2007302, 1822099, 2122320
- **Engineering and Physical Sciences Research Council** — 3 paper(s) in corpus; awards: EP/Y028856/1, EP/R013667/1
- **National Key Research and Development Program of China** — 2 paper(s) in corpus; awards: 2020YFB2103604
- **Nvidia** — 2 paper(s) in corpus; awards: no award id recorded
- **Sichuan Province Science and Technology Support Program** — 2 paper(s) in corpus; awards: 2023NSFSC0497, 2023YFG0025, 2023YFG0263
- **Basic and Applied Basic Research Foundation of Guangdong Province** — 2 paper(s) in corpus; awards: 2021A1515011318, grant No. 2023B1515120065
- **UK Research and Innovation** — 1 paper(s) in corpus; awards: no award id recorded

## Collaboration candidates

| Name | Papers in corpus | Latest year | Institutions | Evidence |
|---|---|---|---|---|
| Yiyu Shi | 6 | — | — | 6 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Marceau Lafargue-Hauret | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Raghav Mehta | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Fabio De Sousa Ribeiro | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Mélanie Roschewitz | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Ben Glocker | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Chenyu You | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Yawen Wu | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Jingtong Hu | 3 | — | — | 3 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Shuang Zeng | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |

> Research similarity is not evidence of availability, willingness or funding. Contact details are never inferred.