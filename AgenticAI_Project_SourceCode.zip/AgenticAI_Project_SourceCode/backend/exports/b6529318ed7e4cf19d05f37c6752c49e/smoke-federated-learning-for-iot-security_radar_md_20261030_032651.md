# Venue, funding and collaboration radar — smoke federated learning for IoT security

**Topic:** federated learning for IoT security

## Venues

| Venue (as seen in literature) | Verification | Publisher | ISSN | Papers | Note |
|---|---|---|---|---|---|
| Blockchain and Federated Learning for Next-Generation IoT Security | unverified | — | — | 5 | Crossref returned no matching journal record; treat this venue as unverified. |
| arXiv cs.LG/cs.AI | unverified | — | — | 2 | Crossref returned no matching journal record; treat this venue as unverified. |
| International Conference on Circuit, Power and Computing Technologies | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |
| i-manager’s Journal on Cloud Computing | verified | i-manager Publications | 2349-6835 | 1 | Verified against the Crossref journal registry (title/ISSN/publisher). Impact factor and acceptance  |
| International Conference on Artificial Intelligence and Signal Processing (AISP) | unverified | — | — | 1 | Crossref returned no matching journal record; treat this venue as unverified. |

## Funders active in this literature

- **Academy of Finland** — 1 paper(s) in corpus; awards: no award id recorded
- **Business Finland** — 1 paper(s) in corpus; awards: no award id recorded
- **Shanxi Province Science Foundation for Youths** — 1 paper(s) in corpus; awards: 201901D211306
- **Australian Research Council** — 1 paper(s) in corpus; awards: DP200101374, DP180102828
- **U.S. Department of Defense** — 1 paper(s) in corpus; awards: W911NF2020277
- **Army Research Laboratory** — 1 paper(s) in corpus; awards: W911NF-20 2-0277, W911NF
- **National Research Foundation** — 1 paper(s) in corpus; awards: BK21 FOUR
- **Sungkyunkwan University** — 1 paper(s) in corpus; awards: RS[2019-II19(0421)], RS[2024-0040(5650)], RS[2024-0044(0881)]

## Collaboration candidates

| Name | Papers in corpus | Latest year | Institutions | Evidence |
|---|---|---|---|---|
| Shiva Mehta | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Ayush Dogra | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Shanmugasundaram Hariharan | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Manjesh K. Hanawal | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Seyedamin Pouriyeh | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Reza M. Parizi | 2 | — | — | 2 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| N P Kumbhar | 1 | — | — | 1 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Prashant V. Mane-Deshmukh | 1 | — | — | 1 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Shahnawaz Ahmad | 1 | — | — | 1 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |
| Mohd. Aquib Ansari | 1 | — | — | 1 paper(s) in the retrieved set on this exact query; topic overlap is measured by co-occurrence in those records. |

> Research similarity is not evidence of availability, willingness or funding. Contact details are never inferred.