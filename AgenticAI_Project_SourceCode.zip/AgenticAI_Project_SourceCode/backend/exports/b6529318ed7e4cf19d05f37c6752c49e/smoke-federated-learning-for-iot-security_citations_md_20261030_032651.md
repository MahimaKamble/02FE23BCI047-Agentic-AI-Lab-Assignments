# Citation audit — smoke federated learning for IoT security

**Topic:** federated learning for IoT security
**Draft version:** 1

| Check | Result |
|---|---|
| References | 12 |
| In-text markers | 12 |
| DOI resolved | 11 |
| DOI failed | 0 |
| DOI unavailable | 1 |
| Missing bibliography entries | 0 |
| Unused bibliography entries | 0 |
| Duplicate references | 0 |

> Metadata verification confirms that a DOI resolves and that title/year/authors broadly agree. It does NOT show that the source supports any specific claim in the manuscript. Claim-level checking requires reading the cited text and is out of scope for this automated audit.

## Per-reference results

| Key | Title | DOI | Metadata check | Issues |
|---|---|---|---|---|
| P1 | The Impact of Federated Learning on IoT Security: An Empiric | 10.1109/iccpct61902.2024.10673009 | verified | none |
| P2 | Federated learning-based IoT security model for privacy pres | 10.26634/jcc.12.2.22361 | verified | none |
| P3 | Robustness Analysis of Federated Learning for IoT Security | 10.1109/aisp68263.2025.11396123 | verified | none |
| P4 | Application of Federated Learning in IoT Security for Signat | 10.1109/discover66922.2025.11259015 | verified | none |
| P5 | Federated Learning for Malware Detection in IoT Devices | 10.1016/j.comnet.2021.108693 | verified | none |
| P6 | Towards Federated Learning-based IoT Security | — | unavailable | no DOI for this record — metadata cannot be verified automatically |
| P7 | Exploring Security Economics in IoT Standardization Efforts | 10.14722/diss.2018.23009 | verified | none |
| P8 | Federated and Transfer Learning: A Survey on Adversaries and | 10.1007/978-3-031-11748-0_3 | verified | none |
| P9 | A Decentralized Security Paradigm for IoT Ecosystems Using B | 10.70593/978-93-7185-127-5_1 | verified | none |
| P10 | Synergizing Blockchain and Federated Learning for Scalable , | 10.70593/978-93-7185-127-5_6 | verified | none |
| P11 | Blockchain–Integrated Federated Learning Arcitectures for Tr | 10.70593/978-93-7185-127-5_2 | verified | none |
| P12 | An Intelligent Decentralized Framework for Next-Generation I | 10.70593/978-93-7185-127-5_5 | verified | none |