# Literature list — smoke federated learning for IoT security

**Topic:** federated learning for IoT security  
**Records:** 15  
**Exported:** 2026-10-30T03:26:51+00:00  
**Provenance:** retrieved from OpenAlex / Crossref / arXiv by project `b6529318ed7e4cf19d05f37c6752c49e`

| # | Title | Year | Venue | Identifier | Sources | Rank |
|---|---|---|---|---|---|---|
| 1 | The Impact of Federated Learning on IoT Security: An Empirical Analysis | 2024 | International Conference on Circuit, Pow | 10.1109/iccpct61902.2024.10673009 | openalex | 0.759 |
| 2 | Federated learning-based IoT security model for privacy preserving analytics | 2026 | i-manager’s Journal on Cloud Computing | 10.26634/jcc.12.2.22361 | openalex | 0.749 |
| 3 | Robustness Analysis of Federated Learning for IoT Security | 2025 | International Conference on Artificial I | 10.1109/aisp68263.2025.11396123 | openalex | 0.739 |
| 4 | Application of Federated Learning in IoT Security for Signature Based Attacks | 2025 | IEEE International Conference on Distrib | 10.1109/discover66922.2025.11259015 | openalex | 0.739 |
| 5 | Federated Learning for Malware Detection in IoT Devices | 2021 | arXiv cs.CR/cs.LG | 10.1016/j.comnet.2021.108693 | arxiv | 0.640 |
| 6 | Towards Federated Learning-based IoT Security | 2020 | DigitalCommons - Kennesaw State Universi | https://openalex.org/W3088219635 | openalex | 0.603 |
| 7 | Exploring Security Economics in IoT Standardization Efforts | 2018 | arXiv cs.CR/cs.CY | 10.14722/diss.2018.23009 | arxiv | 0.497 |
| 8 | Federated and Transfer Learning: A Survey on Adversaries and Defense Mechanisms | 2022 | arXiv cs.LG/cs.AI | 10.1007/978-3-031-11748-0_3 | arxiv | 0.494 |
| 9 | A Decentralized Security Paradigm for IoT Ecosystems Using Blockchain Enabled Federated Learning | 2026 | Blockchain and Federated Learning for Ne | 10.70593/978-93-7185-127-5_1 | crossref | 0.475 |
| 10 | Synergizing Blockchain and Federated Learning for Scalable , Security and Privacy-Aware IoT Systems. | 2026 | Blockchain and Federated Learning for Ne | 10.70593/978-93-7185-127-5_6 | crossref | 0.475 |
| 11 | Blockchain–Integrated Federated Learning Arcitectures for Trustworthy and Privacy–Preserving IoT Security | 2026 | Blockchain and Federated Learning for Ne | 10.70593/978-93-7185-127-5_2 | crossref | 0.475 |
| 12 | An Intelligent Decentralized Framework for Next-Generation IoT Security Using Blockchain and Federated Learnin | 2026 | Blockchain and Federated Learning for Ne | 10.70593/978-93-7185-127-5_5 | crossref | 0.475 |
| 13 | Efficient Vertical Federated Learning with Secure Aggregation | 2023 | arXiv cs.LG/cs.AI | arXiv:2305.11236 | arxiv | 0.431 |
| 14 | Enhancing IoT Security and Trust Management Through Blockchain-Based Federated Learing Models | 2026 | Blockchain and Federated Learning for Ne | 10.70593/978-93-7185-127-5_4 | crossref | 0.427 |
| 15 | VAFL: a Method of Vertical Asynchronous Federated Learning | 2020 | arXiv cs.LG/cs.DC | arXiv:2007.06081 | arxiv | 0.356 |